# ML-Integrated-Smart-Camera
